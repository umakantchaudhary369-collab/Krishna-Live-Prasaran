package com.krishnalive.prasaran

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Saffron = Color(0xFFB85C12)
private val Cream = Color(0xFFFFF8EE)
private val Deep = Color(0xFF4A2412)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { KrishnaApp() }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun KrishnaApp() {
    var selected by remember { mutableStateOf("Home") }
    var showLogin by remember { mutableStateOf(false) }
    MaterialTheme(colorScheme = lightColorScheme(primary = Saffron, background = Cream, surface = Color.White)) {
        Scaffold(
            containerColor = Cream,
            topBar = {
                TopAppBar(
                    title = { Column { Text("कृष्णा लाइव प्रसारण", fontWeight = FontWeight.Bold, color = Deep); Text("Bhakti • Satsang • Live", fontSize = 12.sp, color = Saffron) } },
                    actions = { IconButton(onClick = { showLogin = true }) { Icon(Icons.Default.AccountCircle, contentDescription = "Login", tint = Saffron) } },
                    colors = TopAppBarDefaults.topAppBarColors(containerColor = Cream)
                )
            },
            bottomBar = {
                NavigationBar(containerColor = Color.White) {
                    listOf("Home", "Live", "Videos", "Programs", "Profile").forEach { item ->
                        val icon = when (item) { "Home" -> Icons.Default.Home; "Live" -> Icons.Default.LiveTv; "Videos" -> Icons.Default.PlayCircle; "Programs" -> Icons.Default.Event; else -> Icons.Default.Person }
                        NavigationBarItem(selected = selected == item, onClick = { selected = item }, icon = { Icon(icon, contentDescription = item) }, label = { Text(item, fontSize = 10.sp) })
                    }
                }
            }
        ) { padding ->
            if (showLogin) {
                LoginScreen(Modifier.padding(padding), onBack = { showLogin = false })
            } else {
                when (selected) {
                    "Live" -> ContentScreen(Modifier.padding(padding), "Live Prasaran", "यहाँ आधिकारिक YouTube Live लिंक जोड़ने के बाद लाइव प्रसारण खुलेगा।", listOf("श्रीमद भागवत कथा", "आज का सत्संग", "आरती और भजन"))
                    "Videos" -> ContentScreen(Modifier.padding(padding), "Bhakti Videos", "भजन, कथा और प्रवचन वीडियो", listOf("श्रीमद भागवत कथा", "कृष्ण भजन", "प्रेरणादायक प्रवचन"))
                    "Programs" -> ContentScreen(Modifier.padding(padding), "कार्यक्रम", "आने वाले धार्मिक कार्यक्रम", listOf("सुबह की आरती — समय जल्द जोड़ा जाएगा", "सत्संग — विवरण जल्द जोड़ा जाएगा", "विशेष कथा — विवरण जल्द जोड़ा जाएगा"))
                    "Profile" -> ContentScreen(Modifier.padding(padding), "आपकी प्रोफाइल", "लॉगिन सुविधा अभी डेमो रूप में है।", listOf("Login / Register", "Notifications", "Contact"), action = { showLogin = true })
                    else -> HomeScreen(Modifier.padding(padding), onLive = { selected = "Live" }, onVideos = { selected = "Videos" }, onPrograms = { selected = "Programs" }, onLogin = { showLogin = true })
                }
            }
        }
    }
}

@Composable
fun HomeScreen(modifier: Modifier, onLive: () -> Unit, onVideos: () -> Unit, onPrograms: () -> Unit, onLogin: () -> Unit) {
    LazyColumn(modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        item {
            Card(shape = RoundedCornerShape(24.dp), colors = CardDefaults.cardColors(containerColor = Deep), modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(22.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("॥ श्री कृष्ण शरणम् मम ॥", color = Color(0xFFFFD28A), fontSize = 14.sp)
                    Text("भक्ति से जुड़ें,\nहर दिन कृष्ण के संग", color = Color.White, fontSize = 27.sp, fontWeight = FontWeight.Bold, lineHeight = 34.sp)
                    Text("Live प्रसारण • भजन • कथा • सत्संग", color = Color(0xFFFFE6C4))
                    Button(onClick = onLive, colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFFFD28A), contentColor = Deep)) { Icon(Icons.Default.PlayArrow, null); Spacer(Modifier.width(6.dp)); Text("Watch Live") }
                }
            }
        }
        item { Text("मुख्य सेवाएँ", fontSize = 20.sp, fontWeight = FontWeight.Bold, color = Deep) }
        item { FeatureCard("Live Prasaran", "लाइव कथा और सत्संग देखें", Icons.Default.LiveTv, onLive) }
        item { FeatureCard("Bhakti Videos", "भजन और पुराने कार्यक्रम", Icons.Default.PlayCircle, onVideos) }
        item { FeatureCard("कार्यक्रम", "आने वाले धार्मिक कार्यक्रम", Icons.Default.Event, onPrograms) }
        item { FeatureCard("Login / Register", "अपनी प्रोफाइल खोलें", Icons.Default.Person, onLogin) }
        item { Text("नोट: यह पहला डेमो संस्करण है। असली लॉगिन, वीडियो लिंक, नोटिफिकेशन और एडमिन कंट्रोल जोड़ने के लिए आगे सेटअप करना होगा।", fontSize = 12.sp, color = Color.DarkGray) }
    }
}

@Composable
fun FeatureCard(title: String, subtitle: String, icon: androidx.compose.ui.graphics.vector.ImageVector, onClick: () -> Unit) {
    Card(onClick = onClick, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(18.dp), colors = CardDefaults.cardColors(containerColor = Color.White)) {
        Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(48.dp).background(Color(0xFFFFE8CB), RoundedCornerShape(14.dp)), contentAlignment = Alignment.Center) { Icon(icon, null, tint = Saffron) }
            Spacer(Modifier.width(14.dp))
            Column(Modifier.weight(1f)) { Text(title, fontWeight = FontWeight.Bold, color = Deep); Text(subtitle, fontSize = 13.sp, color = Color.DarkGray) }
            Icon(Icons.Default.ChevronRight, null, tint = Saffron)
        }
    }
}

@Composable
fun ContentScreen(modifier: Modifier, title: String, subtitle: String, entries: List<String>, action: (() -> Unit)? = null) {
    Column(modifier.fillMaxSize().padding(18.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Text(title, fontSize = 26.sp, fontWeight = FontWeight.Bold, color = Deep)
        Text(subtitle, color = Color.DarkGray)
        entries.forEach { entry -> Card(colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(16.dp)) { Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) { Icon(Icons.Default.PlayCircle, null, tint = Saffron); Spacer(Modifier.width(12.dp)); Text(entry, color = Deep) } } }
        if (action != null) Button(onClick = action) { Text("Login / Register") }
    }
}

@Composable
fun LoginScreen(modifier: Modifier, onBack: () -> Unit) {
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    Column(modifier.fillMaxSize().padding(22.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Text("Login / Register", fontSize = 25.sp, fontWeight = FontWeight.Bold, color = Deep)
        Text("यह अभी केवल UI डेमो है; वास्तविक अकाउंट बनाने की सेवा अभी जुड़ी नहीं है।", color = Color.DarkGray)
        OutlinedTextField(value = email, onValueChange = { email = it }, label = { Text("Email या मोबाइल") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
        OutlinedTextField(value = password, onValueChange = { password = it }, label = { Text("Password") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
        Button(onClick = { }, modifier = Modifier.fillMaxWidth()) { Text("Continue (Demo)") }
        TextButton(onClick = onBack) { Text("वापस जाएँ") }
    }
}
